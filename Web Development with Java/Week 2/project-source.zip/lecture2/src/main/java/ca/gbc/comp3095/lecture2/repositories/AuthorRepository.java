package ca.gbc.comp3095.lecture2.repositories;

import ca.gbc.comp3095.lecture2.domain.Author;
import org.springframework.data.repository.CrudRepository;

public interface AuthorRepository extends CrudRepository<Author, Long> {




}
