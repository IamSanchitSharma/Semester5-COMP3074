package ca.gbc.comp3095.lecture2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lecture2Application {

    public static void main(String[] args) {
        SpringApplication.run(Lecture2Application.class, args);
    }

}
