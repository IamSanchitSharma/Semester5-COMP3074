var http = require("http")
var cal = require("./arithmetic")

console.log(http)

var server = http.createServer((req, res) => {
    console.log("I am server : " + Date())
    
    console.log(req.url)
    //http://localhost:8088/
    if(req.url == "/"){
        res.write("<h1>Welcome node server</h1>")
        //console.log(JSON.stringify(res))
    }

    //http://localhost:8088/hello
    if(req.url == "/hello"){
        res.write("Hello from node server")
    }

    //http://localhost:8088/gbc
    if(req.url == "/gbc"){
        res.write("George Brown College")
    }

    //http://localhost:8088/add
    if(req.url == "/add"){
        res.write(`SUM : ${cal.sum(10, 40)}`)
    }

    res.end()
})

server.listen(8088, () => {
    console.log("Server running at http://localhost:8088/")
})