//console.log("Hello")
var gbc = require('./gbc_module.js')
var m1 = require("./mymodule")
var cal = require('./arithmetic')
//console.log(module)

console.log(gbc)
console.log(m1.hello)
console.log(m1.greet())

console.log(cal)
console.log(cal.sum(10, 20))
console.log(cal.sub(20, 10))
console.log(cal.div(10, 2))
console.log(cal.mul(10, 20))
console.log(cal.mod(10, 3))

var p1 = new cal.Person(1, "Pritesh")
p1.display()



