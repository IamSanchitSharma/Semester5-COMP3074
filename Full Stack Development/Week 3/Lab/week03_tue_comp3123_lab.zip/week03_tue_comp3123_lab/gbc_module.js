var name = "George Brown College, Toronto"
module.exports = name