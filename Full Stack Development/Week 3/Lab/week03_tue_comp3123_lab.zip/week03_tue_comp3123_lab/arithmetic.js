const add = (a, b) => {
    return a + b
}

const sub = (a, b) => a - b

const div = (a, b) => {
    return a / b
}
const mod = (a, b) => {
    return a % b
}

const mul = (a, b) => {
    return a * b
}

class Person{
    constructor(pid, name){
        this.pid = pid
        this.name = name
    }

    display(){
        console.log('%d - %s', this.pid, this.name)
    }
}

module.exports =  { sum:add, div, mod, mul, sub, Person }