exports.hello = "hello world"
exports.greet = () => {
    return "Welcome to GBC"
}