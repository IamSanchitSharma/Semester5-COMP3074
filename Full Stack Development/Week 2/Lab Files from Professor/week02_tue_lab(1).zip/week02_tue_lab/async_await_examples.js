

function  sayHello() {
    
}
async function myAsync() {
    //Perform network operations

    console.log("Perform network operations")

    //sayHello()
}

myAsync().then(() => {
    console.log("Success")
})

